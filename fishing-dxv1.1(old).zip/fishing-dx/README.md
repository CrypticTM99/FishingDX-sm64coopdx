# Fishing DX v1.3.0

Created by **CrypticTM** for sm64coopdx.

## Gold rod — pole_geo

Custom pole at actors/pole/. Loaded with smlua_model_util_get_id("pole_geo").
Refresh mods so DynOS compiles it. Falls back to wooden post / metal box if missing.

## Rod path

Wood → Metal (40) → Gold (100, pole_geo) → Master (200) → Legendary (1500)

## Notes

- Cancel (B) while fishing returns the bait you used on that cast.
- Rare hotspot rotates about every 10 minutes.
- Host: /fishing give <player> <bait> [amount]
