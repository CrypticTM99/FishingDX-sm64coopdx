const GeoLayout fish_4_geo[] = {
	GEO_NODE_START(),
	GEO_OPEN_NODE(),
		GEO_SCALE(0x00, 245),
		GEO_OPEN_NODE(),
			GEO_DISPLAY_LIST(LAYER_OPAQUE, fish_4_Mesh0_mesh_layer_1),
			GEO_DISPLAY_LIST(LAYER_OPAQUE, fish_4_final_revert_mesh_layer_1),
		GEO_CLOSE_NODE(),
	GEO_CLOSE_NODE(),
	GEO_END(),
};
