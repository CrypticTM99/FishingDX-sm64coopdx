extern const GeoLayout kitty_geo[];
extern Lights1 kitty_mat_0_f3d_lights;
extern u8 kitty_np901b_rgba16[];
extern Vtx kitty_kitty_mesh_layer_1_vtx_0[865];
extern Gfx kitty_kitty_mesh_layer_1_tri_0[];
extern Gfx mat_kitty_mat_0_f3d[];
extern Gfx mat_revert_kitty_mat_0_f3d[];
extern Gfx kitty_kitty_mesh_layer_1[];
extern Gfx kitty_final_revert_mesh_layer_1[];
