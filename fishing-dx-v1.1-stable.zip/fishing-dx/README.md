# Fishing DX v1.1.0

Created by **CrypticTM** for sm64coopdx.

## Features

* Fish across SM64 stages with rods, bait, shops, and prestige after you have $5000 and unlock each rod!
* Castle Grounds boat opens a stage list (Up/Down, A to travel)
* Custom boat in Dire Dire Docks with a solid deck you can stand on
* Hollowfin mystery fish on Tall Tall Mountain (6% bite chance, hardest fight)
* Hosts can enable the dev commands and give bait
* Cancel with B returns your bait; don't worry about those buggy catches

## Custom fishing rod models (WIP)

actors/pole (pole\_geo). Refresh mods so DynOS compiles it.

## Boat

actors/Boat (Boat\_geo). Spawns in DDD with collision pads. Also used for the Castle Grounds travel boat.

