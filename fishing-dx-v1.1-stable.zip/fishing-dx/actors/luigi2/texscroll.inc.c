void scroll_gfx_mat_luigi2_Logo__EMBLEM_() {
	Gfx *mat = segmented_to_virtual(mat_luigi2_Logo__EMBLEM_);

	shift_t(mat, 15, PACK_TILESIZE(0, 26));

};

void scroll_geo_luigi2() {
	scroll_gfx_mat_luigi2_Logo__EMBLEM_();
};
