extern void scroll_gfx_mat_luigi2_Logo__EMBLEM_();
extern void scroll_geo_luigi2();
